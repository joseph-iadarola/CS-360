package com.example.inventoryapp.data.model;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface UserDao {

    //reader queries
    @Query("SELECT * FROM user")
    List<User> getAll();

    @Query("SELECT * FROM user WHERE uid IN (:userIds)")
    List<User> loadAllByIds(int[] userIds);

    //read query used during login
    @Query("SELECT * FROM user WHERE username LIKE :uname AND password LIKE :pass LIMIT 1")
    User findLoginInfo(String uname, String pass);

    //read query used during registration
    @Query("select * from user where username like :uname limit 1")
    boolean usernameExists(String uname);

    //used during registration
    @Insert
    void insertAll(User... users);

    //no function to delete users yet
    @Delete
    void delete(User user);
}
