package com.example.inventoryapp.ui.login;

import static com.example.inventoryapp.data.model.AppDatabase.getDatabase;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.example.inventoryapp.data.model.AppDatabase;
import com.example.inventoryapp.data.model.User;
import com.example.inventoryapp.data.model.UserDao;
import com.example.inventoryapp.inventorymain.Inventory_Main;
import com.example.inventoryapp.databinding.ActivityLoginBinding;

public class LoginActivity extends AppCompatActivity {

    private ActivityLoginBinding binding;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        AppDatabase db = getDatabase(getApplicationContext());
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //bind components
        final EditText usernameEditText = binding.username;
        final EditText passwordEditText = binding.password;
        final Button loginButton = binding.login;
        final Button registerButton = binding.register;

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UserDao userDao = db.userDao();
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                //Check if user has already registered
                if(userDao.findLoginInfo(username,password)!=null){
                    Intent tans = new Intent(LoginActivity.this, Inventory_Main.class);
                    startActivity(tans);
                }else{
                    Toast.makeText(LoginActivity.this,"Login failed. Check username and password.",Toast.LENGTH_SHORT).show();
                }
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                UserDao userDao = db.userDao();
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                //Check if username is already in database
                if(userDao.usernameExists(username)){
                    Toast.makeText(LoginActivity.this, "Username already taken", Toast.LENGTH_LONG).show();
                }
                else{
                    userDao.insertAll(new User(username,password));
                    Toast.makeText(LoginActivity.this, "Registration complete. You may now login", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

}