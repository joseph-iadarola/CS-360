package com.example.inventoryapp.data.model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "item")
public class Item {

    public Item(String i_title, String i_description, int i_quantity){
        this.i_title = i_title;
        this.i_description = i_description;
        this.i_quantity = i_quantity;
    }

    @PrimaryKey(autoGenerate = true)
    public int iid;

    //used for name of Item and when reading the Item table for an item
    @ColumnInfo(name = "Title")
    public String i_title;

    //Long description of an item
    @ColumnInfo(name = "Description")
    public String i_description;

    //number of this item in the database and watched for sms notifications
    @ColumnInfo(name = "Quantity")
    public int i_quantity;





}
