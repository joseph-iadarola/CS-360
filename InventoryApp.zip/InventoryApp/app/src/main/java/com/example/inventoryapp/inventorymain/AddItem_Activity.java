package com.example.inventoryapp.inventorymain;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import com.example.inventoryapp.data.model.AppDatabase;
import com.example.inventoryapp.data.model.Item;
import com.example.inventoryapp.data.model.ItemDao;
import com.example.inventoryapp.databinding.AddItemScreenBinding;

public class AddItem_Activity extends AppCompatActivity {
    private AddItemScreenBinding binding;

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        binding = AddItemScreenBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        final Button confirm = binding.confirmButton;
        final Button cancel = binding.cancelButton;
        final EditText itemTitleComp = binding.editItemTitle;
        final EditText itemDescComp = binding.editItemDescription;
        final EditText itemQuantComp = binding.editItemNum;

        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //retrieves data from edit fields
                String itemTitle = itemTitleComp.getText().toString();
                String itemDescription = itemDescComp.getText().toString();
                int itemQuantity = Integer.parseInt(itemQuantComp.getText().toString());
                //add item to database
                Item newItem = new Item(itemTitle,itemDescription,itemQuantity);
                ItemDao itemDao = AppDatabase.getDatabase().itemDao();
                itemDao.insertItem(newItem);
                finish();
            }


        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Return to main Activity
                finish();
            }
        });


    }

}
