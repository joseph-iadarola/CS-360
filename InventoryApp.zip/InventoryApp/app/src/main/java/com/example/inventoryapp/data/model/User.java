package com.example.inventoryapp.data.model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Data class that captures user information for logged in users retrieved from LoginRepository
 */
@Entity(tableName = "user")
public class User {

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    @PrimaryKey(autoGenerate = true)
    public int uid;

    //main way of looking up user in database
    @ColumnInfo(name = "username")
    public String username;

    @ColumnInfo(name = "password")
    public String password;
}