package com.example.inventoryapp.data.model;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ItemDao {

    //Read queries
    @Query("SELECT * FROM item")
    List<Item> getAll();

    @Query("select * from item where Title like :itemTitle limit 1")
    Item findByTitle(String itemTitle);

    @Query("select * from item where Description like :itemDescription limit 1")
    Item findByDescription(String itemDescription);

    //update query used when incrementing and decrementing item quantity
    @Update
    public void updateItem(Item... items);

    //adds item to database
    @Insert
    void insertItem(Item ... items);

    //removes item from database
    @Delete
    void deleteItem(Item item);
}
