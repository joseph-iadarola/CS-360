package com.example.inventoryapp.data.model;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities ={User.class, Item.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    public abstract UserDao userDao();
    public abstract ItemDao itemDao();

    private static AppDatabase db = null;

    //default getter
    public static AppDatabase getDatabase() {
        return db;
    }

    //getter for initial creation of database
    public static AppDatabase getDatabase(Context appContext) {
        if (db == null) {
            db = Room.databaseBuilder(appContext, AppDatabase.class, "inventory-db").allowMainThreadQueries().build();
        }
        return db;
    }
}

