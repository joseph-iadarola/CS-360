package com.example.inventoryapp.inventorymain;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import com.example.inventoryapp.data.model.AppDatabase;
import com.example.inventoryapp.data.model.Item;
import com.example.inventoryapp.data.model.ItemDao;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.Toast;
import com.example.inventoryapp.databinding.ActivityInventoryMainBinding;
import java.util.List;

public class Inventory_Main extends AppCompatActivity {

    private ActivityInventoryMainBinding binding;
    private InventoryItemAdaptor adaptor;
    private CheckBox smsBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityInventoryMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        final ImageButton logoutButton = binding.logoutButton;
        final ImageButton addItemButton = binding.addItemButton;
        smsBox = binding.smsCheckBox;

        Toolbar toolbar = binding.toolbar;
        setSupportActionBar(toolbar);

        RecyclerView itemListComp = binding.inventory;
        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        itemListComp.setLayoutManager(layoutManager);

        //phone number is not saved to database
        String phoneNumber = "???????";

        //Check for permissions to get phone number
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_SMS, Manifest.permission.READ_PHONE_NUMBERS}, 6);
        } else {
            TelephonyManager tMan = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
            phoneNumber = tMan.getLine1Number();
        }


        ItemDao itemDao = AppDatabase.getDatabase(getApplicationContext()).itemDao();
        List<Item> itemList = itemDao.getAll();
        adaptor = new InventoryItemAdaptor(itemList,smsBox,phoneNumber);
        itemListComp.setAdapter(adaptor);

        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //change view to add item screen
                Intent trans = new Intent(Inventory_Main.this, AddItem_Activity.class);
                startActivity(trans);
            }
        });

        smsBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(smsBox.isChecked()) {
                    if (ActivityCompat.checkSelfPermission(Inventory_Main.this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED)
                        Toast.makeText(Inventory_Main.this, "App is allowed to send SMS text message notifications", Toast.LENGTH_SHORT).show();
                    else {
                        ActivityCompat.requestPermissions(Inventory_Main.this, new String[]{Manifest.permission.SEND_SMS}, 7);
                    }
                }
                else
                    Toast.makeText(Inventory_Main.this, "App is not allowed to send SMS text message notifications", Toast.LENGTH_SHORT).show();
            }
        });

    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        if (requestCode == 7) {
            if (grantResults.length == 1) {
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(Inventory_Main.this, "App is allowed to send SMS text message notifications", Toast.LENGTH_SHORT).show();
                } else {
                    smsBox.setChecked(false);
                }
            }
            return;
        }
        if (grantResults.length == 3 && grantResults[0] == grantResults[1] && grantResults[0] == grantResults[2] && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            TelephonyManager tMan = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);

            // Android Studio complains that no permission check has occurred when it in fact has occurred
            this.adaptor.setPhoneNumber(tMan.getLine1Number());
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
    @Override
    public void onResume() {
        super.onResume();
        adaptor.reloadItems(AppDatabase.getDatabase(getApplicationContext()).itemDao().getAll());
    }
}